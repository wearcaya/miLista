/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <string>
#include <iostream>
#include "lista.h"
using namespace std;

int main()
{
    Lista<string> ls;
    ls.push_front("one");
    ls.push_front("three");
    ls.push_front("five");
    ls.push_front("seven");
    ls.push_front("nine");
    ls.print();
    cout<<"Hello World";

    return 0;
}
