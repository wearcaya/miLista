#include <cstddef>
#include <iostream>

template<typename T>
class Lista{
#include "Node.h"    
public:
   Lista():head(NULL){}
   void push_front(T d);
   void print();
private:
   Node* head;
};

template<typename T>
void Lista<T>::push_front( T d){
    head = new Node(d,head);
}

template<typename T>
void Lista<T>::print(){
    Node* temp = head;
    while(temp){
      std::cout<< temp->dato << " ";   
      temp = temp->next;
    }
    std::cout<<"\n";
}