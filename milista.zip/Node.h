struct Node{
  T dato;
  Node* next;
  Node(T d , Node* n= NULL ):dato(d), next(n){}
  
};